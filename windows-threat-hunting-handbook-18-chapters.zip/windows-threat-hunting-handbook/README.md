# Windows Threat Hunting & Malware Analysis Handbook

## Structure

- `index.html` — handbook landing page and complete table of contents
- `chapters/` — 18 standalone chapter pages
- `assets/style.css` — shared dark theme
- `assets/app.js` — responsive mobile navigation

Open `index.html` in a browser to start reading.

All material is intended for authorized defensive security, threat hunting, incident response, and forensic analysis.
